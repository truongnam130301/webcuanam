# Blog-19CT111
Lập Trình Web Nâng Cao-Blog


Nhóm: Nhóm kín nhiều người biết

---------------------------------------

Thành viên:
- Nguyễn Chí Tâm (Leader)
- Trần Phương Vân

---------------------------------------

Công Việc:
- Nguyễn Chí Tâm(Backend): Tạo dự án và quản lí bằng GitHub, Thiết kế Database và tạo các phương thức Get, Post, Put, Delete (Rest API)
- Trần Phương Vân(Frontend): Tạo giao diện và các chức năng xem, thêm, sửa, xóa của user, article, comment

